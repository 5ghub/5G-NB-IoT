
// include the other header files to make this class work
#include <FreeRTOS_SAMD21.h> //samd21
#include "GameData.h"


#ifndef GAME_MESSAGE_H
#define GAME_MESSAGE_H


  

#endif
