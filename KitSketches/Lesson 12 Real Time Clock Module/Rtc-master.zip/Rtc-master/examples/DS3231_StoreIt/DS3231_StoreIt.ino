
// CONNECTIONS:
// DS3231 SDA --> SDA
// DS3231 SCL --> SCL
// DS3231 VCC --> 3.3v or 5v
// DS3231 GND --> GND

/* for software wire use below
#include <SoftwareWire.h>  // must be included here so that Arduino library object file references work
#include <RtcDS3231.h>

SoftwareWire myWire(SDA, SCL);
RtcDS3231<SoftwareWire> myRtc(myWire);
 for software wire use above */

/* for normal hardware wire use below */
#include <Wire.h> // must be included here so that Arduino library object file references work
#include <RtcDS3231.h>
RtcDS3231<TwoWire> myRtc(Wire);
/* for normal hardware wire use above */


void setup () 
{
    Serial.begin(57600);

    Serial.print("compiled: ");
    Serial.print(__DATE__);
    Serial.println(__TIME__);

    //--------RTC SETUP ------------
    // if you are using ESP-01 then uncomment the line below to reset the pins to
    // the available pins for SDA, SCL
    // Wire.begin(0, 2); // due to limited pins, use pin 0 and 2 for SDA, SCL
    
    myRtc.Begin();

    RtcDateTime compiled = RtcDateTime(__DATE__, __TIME__);
    printDateTime(compiled);
    Serial.println();

    if (!myRtc.IsDateTimeValid()) 
    {
        Serial.println("RTC lost confidence in the DateTime!");
        myRtc.SetDateTime(compiled);
    }

    if (!myRtc.GetIsRunning())
    {
        Serial.println("RTC was not actively running, starting now");
        myRtc.SetIsRunning(true);
    }

    RtcDateTime now = myRtc.GetDateTime();
    if (now < compiled) 
    {
        Serial.println("RTC is older than compile time!  (Updating DateTime)");
        myRtc.SetDateTime(compiled);
    }

    // never assume the myRtc was last configured by you, so
    // just clear them to your needed state
    myRtc.Enable32kHzPin(false);
    myRtc.SetSquareWavePin(DS3231SquareWavePin_ModeNone); 
}

void loop () 
{
    RtcDateTime now = myRtc.GetDateTime();

    printDateTime(now);
    Serial.println();

    for(;;)
    {
        myRtc.SetIsRunning(false);
        Serial.println(">>> myRtc ready for storage <<<");

        delay(10000); // ten seconds
    }
}

#define countof(a) (sizeof(a) / sizeof(a[0]))

void printDateTime(const RtcDateTime& dt)
{
	char datestring[20];

	snprintf_P(datestring, 
			countof(datestring),
			PSTR("%02u/%02u/%04u %02u:%02u:%02u"),
			dt.Month(),
			dt.Day(),
			dt.Year(),
			dt.Hour(),
			dt.Minute(),
			dt.Second() );
    Serial.print(datestring);
}

